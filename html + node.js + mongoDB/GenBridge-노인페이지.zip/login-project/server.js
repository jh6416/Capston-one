const express = require('express');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcryptjs');


dotenv.config();
const app = express();

app.use(session({
    secret: 'your-secret-key', // 반드시 변경할 비밀 키
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false } // HTTPS 사용 시 true로 설정
}));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());


// MongoDB 연결
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB 연결 성공!'))
  .catch(err => console.log('MongoDB 연결 실패:', err));

// MongoDB Schema 정의 (회원 정보)
const userSchema = new mongoose.Schema({
  name: String,
  phone: String,
  gender: String,
  username: { type: String, unique: true },
  password: String,
});

const User = mongoose.model('User', userSchema);

// 정적 파일 폴더 설정
app.use(express.static(path.join(__dirname, 'public')));

// 특정 HTML 파일 경로 설정
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Main.html'));
});

app.get('/MainHome', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'MainHome.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'LoginPage.html'));
});

app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Register.html'));
});

app.get('/first-main', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'FirstMain.html'));
});

app.get('/settings', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Settings.html'));
});

app.get('/qna', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Q&A.html'));
});



app.post('/register', async (req, res) => {
    const { name, phone, gender, username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
        const newUser = new User({ name, phone, gender, username, password: hashedPassword });
        await newUser.save();
        res.status(201).send('회원가입 성공');
    } catch (error) {
        if (error.code === 11000) {
            res.status(400).send('아이디가 중복되었습니다.');
        } else {
            res.status(500).send('서버 오류');
        }
    }
});

// 아이디 중복 확인
app.get('/check-username', async (req, res) => {
  const { username } = req.query;

  try {
    const user = await User.findOne({ username });
    if (user) {
      res.json({ exists: true });
    } else {
      res.json({ exists: false });
    }
  } catch (error) {
    res.status(500).json({ error: '서버 오류' });
  }
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    
    try {
        const user = await User.findOne({ username });

        if (user) {
            const isMatch = await bcrypt.compare(password, user.password);
            if (isMatch) {
                req.session.userId = user._id;
                res.status(200).send('로그인 성공');
            } else {
                res.status(401).send('아이디 또는 비밀번호가 틀렸습니다.');
            }
        } else {
            res.status(401).send('아이디 또는 비밀번호가 틀렸습니다.');
        }
    } catch (error) {
        console.error('로그인 중 오류:', error);
        res.status(500).send('서버 오류');
    }
});

// 서버 시작
app.listen(process.env.PORT, () => {
  console.log(`서버가 ${process.env.PORT}번 포트에서 실행 중입니다.`);
});