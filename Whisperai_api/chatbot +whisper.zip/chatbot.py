import os
import json
from openai import OpenAI
from dotenv import load_dotenv, find_dotenv
import tiktoken
import whisper

_ = load_dotenv(find_dotenv())
API_KEY = os.environ["API_KEY"]
system_prompt = """
사용자가 어떠한 말을 하는지 파악하고,
사용자가 말하는 것에 대답을 해줘
"""

FILENAME = 'message_history.json'
DEFAULT_MODEL = 'gpt-4o'
INPUT_TOKEN_LIMIT = 2048

client = OpenAI(
    api_key=API_KEY
)


def gpt_stream(messages, temperature=0.7, max_tokens = 512,**kwargs):
    response = client.chat.completions.create(
        model=DEFAULT_MODEL,
        messages=messages,
        stream=True,
        temperature = temperature,
        max_tokens = max_tokens,
        **kwargs
    )
    response_content = ""
    
    for chunk in response:
        chunk_content = chunk.choices[0].delta.content
        if chunk_content is not None:
            print(chunk_content, end = '')
            response_content += chunk_content
        
    print()
    return response_content
    
def count_tokens(text, model):
    encoding = tiktoken.encoding_for_model(model)
    tokens = encoding.encode(text)
    return len(tokens)

def count_total_tokens(messages, model):
    total = 0
    for message in messages:
        total += count_tokens(message['content'], model)
    return total

def enforce_token_limit(messages, token_limit, model = DEFAULT_MODEL):
    while count_total_tokens(messages, model) > token_limit:
        if len(messages) > 1:
            messages.pop(1)


def save_to_json(obj, filename):
    try:
        with open(filename, 'w',encoding='utf-8') as file:
            json.dump(obj, file, indent=4,ensure_ascii=False)
    except Exception as e:
        print(f"{filename} 파일에 내용을 저장하는 중에 오류가 발생했습니다: \n{e}")

def load_from_json(filename):
    try:
        with open(filename,'r',encoding='utf-8') as file:
            return json.load(file)
    except Exception as e:
        print(f"{filename} 파일 내용을 읽어오는 중에 오류가 발생했습니다: \n{e}")

def stt(audiofile):
    model = whisper.load_model('base')
    result = model.transcribe(audiofile)
    print(result['text'])


def chatbot():
    messages = load_from_json(FILENAME)
    if not messages:
        messages = [
            {"role":'system','content':system_prompt}
        ]

    print("ChatBot : 안녕하세요! 궁금하신 정보를 입력해주세요.(exit : 종료) : ")
    while True:
        user_input = input("You : ")
        if user_input.lower() == 'exit':
            break
        
        messages.append({"role":"user",'content':user_input})

        print(count_total_tokens(messages,model=DEFAULT_MODEL))
        enforce_token_limit(messages, INPUT_TOKEN_LIMIT)
        print(count_total_tokens(messages,model=DEFAULT_MODEL))

        print("\nChatBot : ",end="")
        response = gpt_stream(messages)
        print()

        messages.append({'role':'assistant','content':response})

        save_to_json(messages, FILENAME)


stt("audio.mp3")
