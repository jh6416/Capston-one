import os
from openai import OpenAI
from dotenv import load_dotenv, find_dotenv
load_dotenv(find_dotenv())

API_KEY = os.environ['API_KEY']

# .env의 API_KEY 환경변수에서 불러오기
_client = OpenAI(api_key=API_KEY)
DEFAULT_MODEL = 'gpt-4o'

def stream_chat(
    messages: list[dict],
    temperature: float = 0.7,
    max_tokens: int = 512,
    **kwargs
) -> str:
    """
    messages 리스트를 GPT-4o 에 스트리밍 요청하고,
    청크 단위로 콘솔에 출력한 뒤 최종 텍스트를 반환합니다.
    """
    resp = _client.chat.completions.create(
        model=DEFAULT_MODEL,
        messages=messages,
        stream=True,
        temperature=temperature,
        max_tokens=max_tokens,
        **kwargs
    )
    content = ""
    for chunk in resp:
        delta = chunk.choices[0].delta.content
        if delta:
            print(delta, end="", flush=True)
            content += delta
    print() 
    return content
