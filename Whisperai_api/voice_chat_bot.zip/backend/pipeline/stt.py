import whisper
import tempfile
import os

_model = whisper.load_model('base')

def transcribe_bytes(data: bytes, filename: str = "audio.mp3") -> str:
    """
    바이트 스트림(mp3, webm, wav 등)을 임시 파일로 저장하고,
    Whisper로 텍스트 변환 후 반환합니다.
    Windows 환경에서는 delete=False로 잠금 이슈를 방지합니다.
    """
    suffix = os.path.splitext(filename)[1] or ".mp3"
    # delete=False로 열어서 FFmpeg가 열 수 있게 한 뒤,
    # with 블록을 나가면 Python 파일 디스크립터가 닫힙니다.
    tmp = tempfile.NamedTemporaryFile(suffix=suffix, delete=False)
    try:
        tmp.write(data)
        tmp.flush()
        tmp.close()  # 여기서 잠금 해제
        result = _model.transcribe(tmp.name)
    finally:
        # 사용이 끝난 임시 파일은 지워 줍니다.``
        os.remove(tmp.name)
    return result["text"]
