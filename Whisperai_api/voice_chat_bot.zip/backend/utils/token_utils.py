import tiktoken

def count_tokens(text: str, model: str) -> int:
    """
    주어진 텍스트가 model 기준으로 몇 토큰인지 계산해 반환합니다.
    """
    enc = tiktoken.encoding_for_model(model)
    return len(enc.encode(text))

def count_total_tokens(messages: list[dict], model: str) -> int:
    """
    messages 리스트의 모든 콘텐츠를 합산해 토큰 수 반환.
    """
    return sum(count_tokens(m['content'], model) for m in messages)

def enforce_token_limit(messages: list[dict], token_limit: int, model: str):
    """
    messages가 token_limit를 넘으면,
    system 메시지 외 1번 인덱스부터 순차적으로 pop() 하여
    토큰 합이 limit 이내로 맞춰지도록 합니다.
    """
    while count_total_tokens(messages, model) > token_limit and len(messages) > 1:
        messages.pop(1)
