import os
from datetime import datetime
from pymongo import MongoClient, ASCENDING
from dotenv import load_dotenv, find_dotenv

# .env에서 MongoDB 연결 정보 로드
load_dotenv(find_dotenv())
MONGO_URI       = os.getenv("MONGODB_URI")
DB_NAME         = os.getenv("MONGODB_DB", "voice_bot")
COLLECTION_NAME = os.getenv("MONGODB_COLLECTION", "history")

_client     = MongoClient(MONGO_URI)
_db         = _client[DB_NAME]
_collection = _db[COLLECTION_NAME]

# 타임스탬프 인덱스 생성 (필요 시 TTL 설정 가능)
_collection.create_index([("timestamp", ASCENDING)])

def save_message(role: str, content: str):
    """
    role('user'/'assistant')와 content, UTC timestamp를 함께 저장합니다.
    """
    _collection.insert_one({
        "role": role,
        "content": content,
        "timestamp": datetime.utcnow()
    })

def load_messages(limit: int = 200) -> list[dict]:
    """
    저장된 메시지를 오래된 순(timestamp 오름차순)으로 최대 limit개 불러옵니다.
    """
    cursor = _collection.find(
        {}, {"_id":0, "role":1, "content":1}
    ).sort("timestamp", ASCENDING).limit(limit)
    return list(cursor)
