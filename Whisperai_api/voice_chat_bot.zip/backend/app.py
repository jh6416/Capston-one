import os
from fastapi import FastAPI, UploadFile, File, Body
from dotenv import load_dotenv, find_dotenv

# 파이프라인·스토리지 모듈 임포트
from pipeline.stt import transcribe_bytes
from pipeline.chat import stream_chat
from storage.mongo_history import load_messages, save_message

# 환경변수 로드
load_dotenv(find_dotenv())

app = FastAPI()
SYSTEM_PROMPT     = os.getenv("SYSTEM_PROMPT")
INPUT_TOKEN_LIMIT = int(os.getenv("INPUT_TOKEN_LIMIT", 2048))

# app.py 중 /api/transcribe 부분
@app.post("/api/transcribe")
async def transcribe_endpoint(file: UploadFile = File(...)):
    data = await file.read()
    # file.filename 이 "voice.mp3"라면 filename="voice.mp3"
    text = transcribe_bytes(data, filename=file.filename)
    save_message("user", text)
    return {"text": text}

@app.post("/api/chat")
async def chat_endpoint(messages: list[dict] = Body(...)):
    """
    클라이언트에서 보낸 메시지 리스트(역할·내용)를
    system prompt를 앞에 붙여 OpenAI로 전송한 뒤 응답을 저장하고 반환합니다.
    """
    # system prompt가 아직 앞에 없으면 넣어 줍니다.
    if not messages or messages[0].get("role") != "system":
        messages.insert(0, {"role": "system", "content": SYSTEM_PROMPT})

    # 토큰 제한은 필요 시 enforce_token_limit 호출
    reply = stream_chat(
        messages,
        temperature=0.7,
        max_tokens=512
    )
    save_message("assistant", reply)
    return {"reply": reply}
