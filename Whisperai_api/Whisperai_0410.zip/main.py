import openai
import whisper
import os
import tkinter as tk
from tkinter import filedialog
import time

# 발급받은 API 키 설정
OPENAI_API_KEY = "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"

# openai API 키 인증
openai.api_key = OPENAI_API_KEY

# Tkinter 설정
root = tk.Tk()
root.withdraw()

# 파일 선택 대화상자
audio_path = filedialog.askopenfilename(
    filetypes=[("Audio Files", "*.mp3 *.wav *.m4a"), ("All Files", "*.*")]
)

if audio_path:
    print(f"Selected file: {audio_path}")
    
    model = whisper.load_model("base")

    try:
        result = model.transcribe(audio_path)
        print("Transcription:\n", result["text"])

        # STT 폴더가 없다면 생성
        folder_path = "./STT"
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)

        # 텍스트 파일로 저장
        timestamp = int(time.time())
        text_file_path = os.path.join(folder_path, f"text_{timestamp}.txt")
        with open(text_file_path, "w", encoding="utf-8") as text_file:
            text_file.write(result['text'])

        print(f"Transcription saved to {text_file_path}")
    except Exception as e:
        print(f"Error transcribing audio: {e}")
else:
    print("No file was selected.")