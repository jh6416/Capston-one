from openai import OpenAI
import sys
import os
import io
import sys
from dotenv import load_dotenv

# utf-8 강제 인코딩 설정
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

load_dotenv()
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

audio_file_path = sys.argv[1]

with open(audio_file_path, "rb") as audio_file:
    transcript = client.audio.transcriptions.create(
        model="whisper-1",
        file=audio_file,
        language="ko"
    )

print(transcript.text)