const express = require('express');
const multer = require('multer');
const cors = require('cors');
const { exec } = require('child_process');
const dotenv = require('dotenv');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegInstaller = require('@ffmpeg-installer/ffmpeg');
const fs = require('fs');

dotenv.config();

const app = express();
ffmpeg.setFfmpegPath(ffmpegInstaller.path);

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => cb(null, 'recording.webm')
});
const upload = multer({ storage });

app.use(cors());
app.use(express.static('public'));

app.post('/upload-audio', upload.single('audio'), (req, res) => {
    const webmFilePath = req.file.path;
    const wavFilePath = 'uploads/recording.wav';

    ffmpeg(webmFilePath)
        .output(wavFilePath)
        .on('end', () => {
            fs.unlink(webmFilePath, (err) => {
                if (err) console.error('webm 파일 삭제 실패:', err);
                else console.log('webm 파일 삭제 완료');
            });

            // 파이썬 스크립트 호출
            const pythonScript = `python whisper_api.py ${wavFilePath}`;
            exec(pythonScript, { encoding: 'utf8' }, (error, stdout, stderr) => {
                if (error) {
                    console.error(`Python 실행 오류: ${error.message}`);
                    return res.status(500).json({ error: 'Whisper API 실행 오류' });
                }
                if (stderr) {
                    console.error(`stderr: ${stderr}`);
                    return res.status(500).json({ error: 'Whisper 처리 오류' });
                }
                res.json({ text: stdout.trim() });
            });
        })
        .on('error', (err) => {
            console.error('ffmpeg 변환 오류:', err);
            res.status(500).json({ error: '오디오 변환 중 오류 발생' });
        })
        .run();
});

app.listen(3000, () => {
    console.log('서버가 포트 3000에서 실행 중입니다.');
});