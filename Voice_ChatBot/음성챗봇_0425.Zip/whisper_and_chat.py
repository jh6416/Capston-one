import os
import io
import json
import sys
from datetime import datetime
from dotenv import load_dotenv, find_dotenv
from openai import OpenAI
import whisper
import tiktoken

load_dotenv(find_dotenv())
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
API_KEY = os.getenv("OPENAI_API_KEY")
HISTORY_FILE = "message_history.json"
SYSTEM_PROMPT = """
당신은 60대 이상 노인분들의 챗봇입니다.

두 가지 경우에 따라 다르게 대답합니다.
# 노인이 질문할 경우
친절하고, 인내심이 많으며, 그들의 질문에 대해 정확하고 유용한 답변을 제공합니다.
그들이 이해하기 쉬운 언어로 대화하며 1줄로 설명해주고
자세한것은 청년에게 물어볼까요? 라고 출력합니다.

# 노인이 감정을 공유하거나 고민을 말할 경우
노인의 감정에 따라 공감하고, 그들의 감정을 이해하며, 
그들의 고민에 대해 진지하게 대답합니다.

"""

# 
def load_history():
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        # 없으면 SYSTEM_PROMPT 생성
        return [{"role": "system", "content": SYSTEM_PROMPT}]

def save_history(history):
    with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

def count_tokens(text, model="gpt-4o-mini"):
    enc = tiktoken.encoding_for_model(model)
    return len(enc.encode(text))

def enforce_limit(history, limit=2048, model="gpt-4o-mini"):
    # 가장 오래된 user 메시지(시스템 다음)를 지우며 토큰 제한 맞추기
    while True:
        total = sum(count_tokens(msg["content"], model) for msg in history)
        if total <= limit or len(history) <= 2:
            break
        history.pop(1)

# main() 함수에서 Whisper STT와 ChatCompletion을 호출하는 메인 로직
def main():
    # 1) 입력된 오디오 파일 경로
    if len(sys.argv) < 2:
        print("Usage: python whisper_and_chat.py <audio.wav>", file=sys.stderr)
        sys.exit(1)
    audio_path = sys.argv[1]

    # 2) Whisper STT (local model 사용)
    model = whisper.load_model("base")
    result = model.transcribe(audio_path)
    transcript = result["text"].strip()

    # 3) 기존 대화 이력 불러오기
    history = load_history()
    # user 메시지 추가
    history.append({"role": "user", "content": transcript})

    # 4) 토큰 제한 적용
    enforce_limit(history)

    # 5) ChatCompletion 호출
    client = OpenAI(api_key=API_KEY)
    chat_res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=history,
        temperature=0.7,
        max_tokens=512
    )
    reply = chat_res.choices[0].message.content.strip()

    # 6) assistant 메시지 추가 및 저장
    history.append({"role": "assistant", "content": reply})
    save_history(history)

    # 7) JSON으로 출력 (Node.js가 이걸 stdout으로 받아요)
    output = {"transcript": transcript, "reply": reply}
    print(json.dumps(output, ensure_ascii=False))

if __name__ == "__main__":
    main()
