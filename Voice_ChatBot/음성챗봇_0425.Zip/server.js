// server.js
const express    = require('express');
const multer     = require('multer');
const cors       = require('cors');
const { exec }   = require('child_process');
const dotenv     = require('dotenv');
const ffmpeg     = require('fluent-ffmpeg');
const ffmpegInst = require('@ffmpeg-installer/ffmpeg');
const fs         = require('fs');

dotenv.config();
ffmpeg.setFfmpegPath(ffmpegInst.path);

const app = express();
app.use(cors());
app.use(express.static('public'));

// multer 설정: 업로드된 webm → uploads/recording.webm
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename:    (req, file, cb) => cb(null, 'recording.webm')
});
const upload = multer({ storage });

app.post('/upload-audio', upload.single('audio'), (req, res) => {
    const webmPath = req.file.path;
    const wavPath  = 'uploads/recording.wav';
  
    ffmpeg(webmPath)
      .output(wavPath)
      .on('end', () => {
        fs.unlink(webmPath, () => {});
        // 음성 처리 후 whisper_and_chat.py 실행
        // whisper_and_chat.py 실행 
        exec(`python whisper_and_chat.py ${wavPath}`, { encoding: 'utf8' }, (err, stdout, stderr) => {
          // 에러 발생 시 처리
          if (err) {
            console.error('Python 실행 오류:', err);
            return res.status(500).json({ error: '음성 처리 중 오류 발생' });
          }
          // stderr가 경고만 담고 있을 땐 무시하고, stdout(JSON) 파싱으로 진행
          let result;
          try {
            result = JSON.parse(stdout);
          } catch (parseErr) {
            console.error('JSON 파싱 오류:', parseErr, '원본 stdout:', stdout);
            return res.status(500).json({ error: '응답 파싱 실패' });
          }
          // 변환된 wav 파일을 whisper_and_chat.py에 전달하여 처리
          res.json(result);
          fs.unlink(wavPath, () => {});
        });
  
      })
      .on('error', convErr => {
        console.error('ffmpeg 변환 오류:', convErr);
        res.status(500).json({ error: '오디오 변환 실패' });
      })
      .run();
  });
  

app.listen(3000, () => {
  console.log('서버 실행 중: http://localhost:3000');
});
